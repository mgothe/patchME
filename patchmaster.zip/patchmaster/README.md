Ansible Patching Automation: PatchMaster
=========================================

[![Build Status](https://)

This is an Ansible role to automation patching process.

Requirements
------------

None

Role Variables
--------------
admin_email: milan_gothe@tjx.com

Dependencies
------------

None

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: dev


      roles:
         - { role:  patchme}

License
-------

Commercial

Author Information
------------------

Milan Gothe - https://

